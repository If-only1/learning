print('ds'.encode())
print(b'ds')
